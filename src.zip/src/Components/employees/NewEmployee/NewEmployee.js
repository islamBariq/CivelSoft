import React, { Component } from 'react';
import './newEmployee.css';

export class NewEmployee extends Component {
  render() {
    return (
      <>
        <h1>new employee</h1>
      </>
    );
  }
}

export default NewEmployee;
